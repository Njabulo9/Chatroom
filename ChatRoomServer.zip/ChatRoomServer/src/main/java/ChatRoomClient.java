import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ChatRoomClient extends JFrame {
    private JTextArea chatArea;
    private JTextField messageField;
    private JButton sendButton, panicButton;
    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;

    public ChatRoomClient() {
        setTitle("Emergency Chat Room");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 245));

        // Heading label
        JLabel headingLabel = new JLabel("Emergency Chat Room");
        headingLabel.setForeground(Color.BLUE);
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 22));
        mainPanel.add(headingLabel, BorderLayout.NORTH);

        // Chat area (for displaying messages)
        chatArea = new JTextArea(10, 30);
        chatArea.setBackground(Color.WHITE);
        chatArea.setForeground(Color.BLACK);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Input panel for message field and send button
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBackground(new Color(245, 245, 245));

        messageField = new JTextField();
        messageField.setFont(new Font("Arial", Font.PLAIN, 16));
        inputPanel.add(messageField, BorderLayout.CENTER);

        sendButton = new JButton("Send");
        sendButton.setBackground(new Color(30, 144, 255));
        sendButton.setForeground(Color.WHITE);
        inputPanel.add(sendButton, BorderLayout.EAST);

        // Adding the Panic Button (Red Button)
        panicButton = new JButton("PANIC!");
        panicButton.setBackground(Color.RED);
        panicButton.setForeground(Color.WHITE);
        panicButton.setFont(new Font("Arial", Font.BOLD, 14));
        inputPanel.add(panicButton, BorderLayout.WEST);

        mainPanel.add(inputPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Action listener for the send button (regular message)
        sendButton.addActionListener(e -> {
            String message = messageField.getText();
            if (!message.isEmpty()) {
                out.println(message); // Send message to server
                chatArea.append("You: " + message + "\n");
                messageField.setText("");
            }
        });

        // Action listener for the panic button (emergency message)
        panicButton.addActionListener(e -> {
            String panicMessage = "!!! PANIC !!!";
            out.println(panicMessage); // Send panic message to server
            chatArea.append("!!! You triggered a PANIC message !!!\n");
        });

        // Client-server communication setup
        try {
            socket = new Socket("localhost", 1234); // Connect to the server on localhost and port 1234
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            new Thread(() -> {
                String message;
                try {
                    while ((message = in.readLine()) != null) {
                        chatArea.append(message + "\n");
                    }
                } catch (IOException e) {
                    chatArea.append("Disconnected from server.\n");
                }
            }).start();
        } catch (IOException e) {
            chatArea.append("Unable to connect to server.\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatRoomClient().setVisible(true));
    }
}
