import java.io.*;
import java.net.*;
import java.util.List;   // Correct List import
import java.util.ArrayList;   // Required for client list handling
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class ChatRoomServer extends JFrame {
    private JTextArea chatArea;
    private JTextField messageField;
    private JButton sendButton;
    private List<ClientHandler> clients = new ArrayList<>();

    public ChatRoomServer() {
        setTitle("Emergency Chat Room Server");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(60, 63, 65));

        // Heading label
        JLabel headingLabel = new JLabel("Emergency Chat Room Server");
        headingLabel.setForeground(Color.ORANGE);
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 22));
        mainPanel.add(headingLabel, BorderLayout.NORTH);

        // Chat area (for displaying messages)
        chatArea = new JTextArea(10, 30);
        chatArea.setBackground(new Color(230, 230, 250));
        chatArea.setForeground(Color.BLACK);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Input panel for message field and send button
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBackground(new Color(60, 63, 65));

        messageField = new JTextField();
        messageField.setFont(new Font("Arial", Font.PLAIN, 16));
        inputPanel.add(messageField, BorderLayout.CENTER);

        sendButton = new JButton("Send");
        sendButton.setBackground(new Color(30, 144, 255));
        sendButton.setForeground(Color.WHITE);
        inputPanel.add(sendButton, BorderLayout.EAST);

        mainPanel.add(inputPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Action listener for the send button (admin message)
        sendButton.addActionListener(e -> {
            String message = messageField.getText();
            if (!message.isEmpty()) {
                chatArea.append("Server: " + message + "\n");
                broadcastMessage("Server: " + message);
                messageField.setText("");
            }
        });

        // Server setup and client connections
        try {
            ServerSocket serverSocket = new ServerSocket(1234);
            chatArea.append("Server started...\n");

            new Thread(() -> {
                while (true) {
                    try {
                        Socket socket = serverSocket.accept();
                        ClientHandler clientHandler = new ClientHandler(socket);
                        clients.add(clientHandler);
                        clientHandler.start();
                    } catch (IOException e) {
                        chatArea.append("Error accepting client connection.\n");
                    }
                }
            }).start();
        } catch (IOException e) {
            chatArea.append("Could not start server.\n");
        }
    }

    // Broadcast messages to all clients
    private void broadcastMessage(String message) {
        for (ClientHandler client : clients) {
            client.sendMessage(message);
        }
    }

    private class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);
                String message;

                while ((message = in.readLine()) != null) {
                    // Check if panic message is received
                    if (message.equals("!!! PANIC !!!")) {
                        chatArea.append("*** PANIC ALERT FROM CLIENT ***\n");
                        broadcastMessage("*** PANIC ALERT FROM CLIENT ***");
                    } else {
                        chatArea.append("Client: " + message + "\n");
                        broadcastMessage("Client: " + message);
                    }
                }
            } catch (IOException e) {
                chatArea.append("Client disconnected.\n");
            }
        }

        public void sendMessage(String message) {
            out.println(message); // Send message to the client
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatRoomServer().setVisible(true));
    }
}
